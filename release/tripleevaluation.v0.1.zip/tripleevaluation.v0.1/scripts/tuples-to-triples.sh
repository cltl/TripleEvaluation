java -Xmx812m -cp ../lib/TripleEvaluation-1.0-jar-with-dependencies.jar vu.tripleevaluation.conversion.ConvertTuplesToTriples --tuple-file "../data/kyoto/bus-accident.ont.dep.kaf.sem.tpl" --first-element "event"

