java -cp ../lib/TripleEvaluation-1.0-jar-with-dependencies.jar vu.tripleevaluation.evaluation.EvaluateTriples --gold-standard-triples ../data/11767.tag.trp --system-triples ../data/11767.kaf.kybot.xml.0.trp --token-range ../data/11767.tag.trp.first-element-token-scope --skip-time-and-location

java -cp ../lib/TripleEvaluation-1.0-jar-with-dependencies.jar vu.tripleevaluation.evaluation.EvaluateTriplesDebug --gold-standard-triples ../data/11767.tag.trp --system-triples ../data/11767.kaf.kybot.xml.60.trp --token-range ../data/11767.tag.trp.first-element-token-scope --skip-time-and-location

