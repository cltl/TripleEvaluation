java -cp ../lib/TripleEvaluation-1.0-jar-with-dependencies.jar vu.tripleevaluation.conversion.TripleRelationConversion --triples ../data/11767.tag.trp --relation-mapping ../data/relation-mapping.txt
